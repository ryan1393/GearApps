import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import {
  CutterBuildCard,
  CutterBuildSearchRow,
  CutterBuilderApiService,
  cutterApiErrorText,
  downloadCutterCardArtifacts,
} from '@libs/frontend/data-access-cutter-builder';
import {
  DanaPageHeaderComponent,
  DanaTableDirective,
  DanaTableEmptyDirective,
  DanaTableShellDirective,
} from '@dana/ui';

@Component({
  selector: 'gear-cutter-lookup',
  standalone: true,
  imports: [CommonModule, FormsModule, DanaPageHeaderComponent, DanaTableDirective, DanaTableEmptyDirective, DanaTableShellDirective],
  templateUrl: './cutter-lookup.component.html',
})
export class CutterLookupComponent implements OnInit {
  private readonly api = inject(CutterBuilderApiService);
  private readonly route = inject(ActivatedRoute);

  searchText = '';
  status = '';
  partType = '';
  cutterBody = '';
  results: CutterBuildSearchRow[] = [];
  card: CutterBuildCard | null = null;
  busy = false;
  error = '';
  message = '';

  readonly statuses = ['', 'READY', 'RUNNING', 'SHELF', 'PULLED', 'CLOSED'];
  readonly partTypes = ['', 'RING', 'PINION'];

  ngOnInit(): void {
    const build = this.route.snapshot.queryParamMap.get('build')?.trim();
    if (build) {
      this.searchText = build;
      this.openCard(build);
      return;
    }
    this.search();
  }

  search(): void {
    this.busy = true;
    this.error = '';
    this.message = '';
    this.card = null;

    this.api.searchBuilds({
      q: this.searchText,
      status: this.status,
      partType: this.partType,
      cutterBody: this.cutterBody,
      limit: 100,
    }).subscribe({
      next: (rows) => {
        this.results = rows;
        this.busy = false;
      },
      error: (err: HttpErrorResponse) => {
        this.busy = false;
        this.error = cutterApiErrorText(err, 'Could not search cutter builds.');
      },
    });
  }

  openCard(buildNumber: string): void {
    this.busy = true;
    this.error = '';
    this.message = '';
    this.api.getCard(buildNumber).subscribe({
      next: (card) => {
        this.card = card;
        this.searchText = card.build_number;
        this.busy = false;
      },
      error: (err: HttpErrorResponse) => {
        this.busy = false;
        this.error = cutterApiErrorText(err, 'Cutter build not found.');
      },
    });
  }

  clear(): void {
    this.searchText = '';
    this.status = '';
    this.partType = '';
    this.cutterBody = '';
    this.card = null;
    this.search();
  }

  print(): void {
    const buildNumber = this.card?.build_number;
    if (!buildNumber || this.busy) return;
    this.error = '';
    this.message = '';
    this.busy = true;
    this.api.getCard(buildNumber).subscribe({
      next: (card) => {
        this.card = card;
        void downloadCutterCardArtifacts(card)
          .then(({ prnFileName, pngFileName }) => {
            this.message = 'Saved ' + prnFileName + ' and ' + pngFileName + '.';
          })
          .catch((error: unknown) => {
            this.error = error instanceof Error ? error.message : 'Could not export the Cutter Card files.';
          })
          .finally(() => {
            this.busy = false;
          });
      },
      error: (err: HttpErrorResponse) => {
        this.busy = false;
        this.error = cutterApiErrorText(err, 'Could not load the Cutter Card for export.');
      },
    });
  }

  browserPrint(): void {
    window.print();
  }
}
