import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthSessionService } from '@libs/frontend/data-access-user';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const accessToken = inject(AuthSessionService).accessToken;
  if (!accessToken) return next(req);

  return next(req.clone({
    setHeaders: { Authorization: `Bearer ${accessToken}` },
  }));
};
