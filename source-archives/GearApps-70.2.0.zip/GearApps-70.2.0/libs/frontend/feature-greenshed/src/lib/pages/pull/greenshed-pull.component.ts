import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GearToastService } from '@libs/frontend/util-common';
import { buildSummaryShelfTag, normalizeSummaryNumber } from '@libs/shared/util-constants';
import { ILocation } from '@libs/shared/util-types';
import { GreenshedApiService, GreenshedBuild, GreenshedPullResult, GreenshedReferenceData, greenshedApiErrorText } from '@libs/frontend/data-access-greenshed';
import {
  DanaPageHeaderComponent,
} from '@dana/ui';

@Component({selector:'gear-greenshed-pull',standalone:true,imports: [CommonModule, FormsModule, DanaPageHeaderComponent],templateUrl:'./greenshed-pull.component.html'})
export class GreenshedPullComponent implements OnInit {
 private readonly api=inject(GreenshedApiService); private readonly route=inject(ActivatedRoute); private readonly toast=inject(GearToastService);refs:GreenshedReferenceData|null=null;build:GreenshedBuild|null=null;buildNumber='';availableRunningBuilds:Array<{build_number:string;machine_number:string;summary_number:string;part_type_code:string}>=[];reasonCode='';shelfSerial='';shelf:ILocation|null=null;comments='';busy=false;error='';message='';result:GreenshedPullResult|null=null;
 ngOnInit(){
  const requestedReason=this.route.snapshot.queryParamMap.get('reason')?.trim().toUpperCase();
  this.api.getDashboard().subscribe({next:d=>this.availableRunningBuilds=d.active_machines.map(x=>({build_number:x.build_number,machine_number:x.machine_number,summary_number:x.summary_number,part_type_code:x.part_type_code})),error:()=>this.availableRunningBuilds=[]});
  this.api.getReferenceData().subscribe({next:r=>{
    this.refs=r;
    // An exact code wins. "CHANGEOVER" (sent by the Running Machines changeover action)
    // means the configured return-to-shelf reason, e.g. Dana's PCR_002, never a
    // teardown reason that happens to sort first.
    const changeover = r.pull_reasons.find(x=>x.returns_to_shelf&&!x.requires_teardown);
    this.reasonCode =
      requestedReason && r.pull_reasons.some(x=>x.code===requestedReason)
        ? requestedReason
        : requestedReason==='CHANGEOVER'
          ? changeover?.code ?? '' // no return-to-shelf reason configured: make the operator choose
          : r.pull_reasons[0]?.code??'';
  }});
  const build=this.route.snapshot.queryParamMap.get('build')?.trim();
  if(build){this.buildNumber=build;this.scanBuild();}
 }
 get expectedShelfSerial(){return this.build?buildSummaryShelfTag('GREENSHED',this.build.summary_number,this.build.part_type_code):null;}
 selectBuild(){if(this.buildNumber)this.scanBuild();}
 selectShelf(){if(this.shelfSerial)this.scanShelf();}
 get reason(){return this.refs?.pull_reasons.find(x=>x.code===this.reasonCode)??null;}
 scanBuild(){const value=this.buildNumber.trim();if(!value)return;this.resetPullDownstream(false);this.build=null;this.busy=true;this.error='';this.message='';this.api.getBuild(value).subscribe({next:b=>{this.build=b;this.buildNumber=b.build_number;this.busy=false;if(b.status_code!=='RUNNING')this.error=`Build ${b.build_number} is not RUNNING.`;},error:(e:HttpErrorResponse)=>{this.busy=false;this.error=greenshedApiErrorText(e,'Build not found.');}});}
 scanShelf(){if(!this.shelfSerial.trim())return;this.busy=true;this.error='';this.api.scanLocation(this.shelfSerial).subscribe({next:l=>{this.busy=false;const expected=this.build?buildSummaryShelfTag('GREENSHED',this.build.summary_number,this.build.part_type_code):null;if(!expected||l.location_type!=='SHELF'||l.department!=='GREENSHED'||l.number!==normalizeSummaryNumber(this.build?.summary_number??'')||l.serial_number!==expected){this.shelf=null;this.error=expected?`Summary ${this.build?.summary_number} cutter must go to ${expected}.`:'Scan the cutter build before scanning its Green Shed shelf.';return;}this.shelf=l;this.shelfSerial=l.serial_number;},error:(e:HttpErrorResponse)=>{this.busy=false;this.shelf=null;this.error=greenshedApiErrorText(e,'Shelf location not found.');}});}
 onReasonChange(){this.shelfSerial='';this.shelf=null;this.result=null;this.message='';}
 reset(){this.build=null;this.buildNumber='';this.comments='';this.result=null;this.error='';this.message='';this.resetPullDownstream(true);}
 private resetPullDownstream(preserveReason:boolean){this.shelfSerial='';this.shelf=null;this.comments='';this.result=null;if(!preserveReason&&this.refs){this.reasonCode=this.refs.pull_reasons[0]?.code??'';}}
 pull(){if(this.busy)return;if(!this.build||!this.reason)return;if(this.reason.returns_to_shelf&&!this.shelf)return;
 const destination=this.reason.returns_to_shelf?(this.shelf?.serial_number??'selected shelf'):'Cutter Builder';
 if(!globalThis.confirm(`Pull cutter ${this.build.build_number}?\n\nReason: ${this.reason.name}\nDestination: ${destination}\n\nThis records the cutter pull transaction.`))return;
 this.busy=true;this.error='';this.api.pullCutter({buildNumber:this.build.build_number,reasonCode:this.reason.code,shelfLocationSerial:this.shelf?.serial_number??null,comments:this.comments}).subscribe({next:r=>{this.busy=false;this.result=r;const message=this.reason?.returns_to_shelf?`Cutter returned intact to ${this.shelf?.serial_number}.`:'Cutter pulled and is ready to return to Cutter Builder.';this.message='';this.toast.success(message,'Cutter pull complete');this.api.getDashboard().subscribe({next:d=>this.availableRunningBuilds=d.active_machines.map(x=>({build_number:x.build_number,machine_number:x.machine_number,summary_number:x.summary_number,part_type_code:x.part_type_code})),error:()=>{}});},error:(e:HttpErrorResponse)=>{this.busy=false;const message=greenshedApiErrorText(e,'Could not pull cutter.');this.error='';this.toast.error(message,'Cutter pull failed');}});}
}
