import { Response } from 'express';
import { STATUS_CODES } from 'http';
import { QueryFailedError } from 'typeorm';

import { ArgumentsHost, Catch, HttpStatus, Logger } from '@nestjs/common';
import { BaseExceptionFilter, Reflector } from '@nestjs/core';

export function isQueryFailedError(
  thrownValue: unknown,
): thrownValue is QueryFailedError {
  return thrownValue instanceof QueryFailedError;
}

/**
 *
 * @see https://stackoverflow.com/a/66519642
 * @see https://github.com/NarHakobyan/awesome-nest-boilerplate/blob/e70667eac4421fb462ca2d0ad4ddb670242293f7/src/filters/query-failed.filter.ts
 */
@Catch(QueryFailedError)
export class QueryFailedFilter extends BaseExceptionFilter {
  constructor(public reflector: Reflector) {
    super();
  }

  public override catch(
    exception: QueryFailedError & { constraint?: string },
    host: ArgumentsHost,
  ) {
    const driverError = (exception as QueryFailedError & {
      driverError?: {
        code?: string;
        detail?: string;
        table?: string;
        column?: string;
        constraint?: string;
        message?: string;
      };
      query?: string;
      parameters?: unknown[];
    }).driverError;

    const databaseDetail = [
      exception.message,
      driverError?.message,
      driverError?.detail,
      driverError?.code ? `code=${driverError.code}` : undefined,
      driverError?.table ? `table=${driverError.table}` : undefined,
      driverError?.column ? `column=${driverError.column}` : undefined,
      exception.constraint ? `constraint=${exception.constraint}` : undefined,
    ]
      .filter(Boolean)
      .join(' | ');

    Logger.error(`Database query failed: ${databaseDetail}`);
    if ((exception as QueryFailedError & { query?: string }).query) {
      Logger.error(
        `Failed SQL: ${(exception as QueryFailedError & { query?: string }).query}`,
      );
    }

    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const status = exception.constraint?.startsWith('UQ')
      ? HttpStatus.CONFLICT
      : HttpStatus.INTERNAL_SERVER_ERROR;

    response.status(status).json({
      error: STATUS_CODES[status],
      message:
        status === HttpStatus.CONFLICT
          ? 'A record with that value already exists'
          : 'A database error occurred',
      ...(process.env['NODE_ENV'] !== 'production' && status !== HttpStatus.CONFLICT
        ? { detail: databaseDetail }
        : {}),
    });
  }
}
