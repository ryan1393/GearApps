import * as crypto from 'crypto';
import { FindOptionsWhere, Repository } from 'typeorm';

import {
  CreateUserDto,
  DepartmentOrmEntity,
  PaginationOptionsDto,
  PaginationService,
  UserOrmEntity,
} from '@libs/server/data-access';
import {
  IResetPasswordEmailContext,
  IVerifyEmailContext,
  ServerUtilMailerService,
} from '@libs/server/util-mailer';
import {
  AuthProviderType,
  IForgotPasswordPayload,
  IPaginatedResponse,
  IResetPasswordPayload,
  IUser,
  IUserEntity,
  RoleType,
  Uuid,
} from '@libs/shared/util-types';
import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class ServerFeatUserService extends PaginationService<UserOrmEntity> {
  private readonly logger = new Logger(ServerFeatUserService.name);

  private get publicApiBaseUrl(): string {
    const configured =
      this.configService.get<string>('PUBLIC_API_BASE_URL') ??
      'http://localhost:3333';
    return configured.replace(/\/+$/, '');
  }

  constructor(
    @InjectRepository(UserOrmEntity)
    private userRepo: Repository<UserOrmEntity>,
    @InjectRepository(DepartmentOrmEntity)
    private departmentRepo: Repository<DepartmentOrmEntity>,
    private emailService: ServerUtilMailerService,
    private configService: ConfigService,
  ) {
    super(UserOrmEntity.prototype, userRepo);
  }

  async findUser(
    find: FindOptionsWhere<UserOrmEntity>,
  ): Promise<UserOrmEntity | null> {
    return this.userRepo.findOneBy(find);
  }

  async findByEmail(email: string): Promise<UserOrmEntity | null> {
    return this.userRepo.findOne({
      where: { email },
      relations: { department: true },
    });
  }

  async createUser(dto: CreateUserDto): Promise<UserOrmEntity> {
    if (dto.socialProvider === AuthProviderType.EMAIL && dto.socialId) {
      throw new BadRequestException(
        `User can not provide a social ID while registering with an email address!`,
      );
    }

    // assume that since a 3rd party is being for registration, their email is verified already
    const user = this.userRepo.create({
      ...dto,
      role: RoleType.USER,
      isEmailVerified: dto.socialProvider !== AuthProviderType.EMAIL,
    });
    await user.save();

    if (dto.socialProvider === AuthProviderType.EMAIL) {
      if (!user.email) {
        throw new BadRequestException(
          'An email address is required for email authentication',
        );
      }
      const email = user.email;
      const context: IVerifyEmailContext = {
        verificationLink: `${this.publicApiBaseUrl}/api/v1/auth/email/verify?code=${user.verificationHash}&email=${encodeURIComponent(email)}`,
        userEmailAddress: email,
        title: 'Verify Your Email',
        username: user.firstName ?? email,
      };
      await this.emailService.sendMail({
        templatePath: 'verify-email.hbs',
        context,
        to: email,
        subject: `Verify Your Email`,
      });
    }
    return user;
  }

  async createUserByAdmin(
    dto: {
      email: string;
      password: string;
      firstName?: string | null;
      lastName?: string | null;
      role: RoleType;
      departmentId: Uuid;
    },
    adminUserId: Uuid,
  ): Promise<UserOrmEntity> {
    const department = await this.departmentRepo.findOne({
      where: { id: dto.departmentId, enabled: true },
    });
    if (!department) {
      throw new UnprocessableEntityException(
        'User department was not found or is disabled',
      );
    }

    const existing = await this.findByEmail(dto.email);
    if (existing) {
      throw new ConflictException(`User ${dto.email} already exists`);
    }

    const user = this.userRepo.create({
      email: dto.email,
      password: dto.password,
      firstName: dto.firstName ?? null,
      lastName: dto.lastName ?? null,
      avatar: null,
      role: dto.role,
      departmentId: department.id,
      active: true,
      socialProvider: AuthProviderType.EMAIL,
      socialId: null,
      isEmailVerified: true,
      emailVerifiedOn: new Date(),
      verificationHash: null,
      createdBy: adminUserId,
      updatedBy: adminUserId,
    });

    await user.save();

    // The entity subscriber creates a verification hash for all local-auth
    // inserts. Admin-created accounts are intentionally already verified.
    if (user.verificationHash) {
      user.verificationHash = null;
      await user.save();
    }

    return user;
  }

  async getUser(userId: Uuid) {
    return await this.userRepo.findOneOrFail({
      where: { id: userId },
      relations: { department: true },
    });
  }

  async getUsers(
    paginationOptions?: PaginationOptionsDto,
  ): Promise<IPaginatedResponse<IUser>> {
    return this.paginate<IUser>(paginationOptions, (entity) => entity.toJSON());
  }

  async getUserByEmail(email: string): Promise<UserOrmEntity> {
    const user = await this.userRepo.findOne({
      where: {
        email,
      },
    });

    if (!user) {
      throw new NotFoundException(`User could not be found!`);
    }

    return user;
  }

  async updateUser(userId: Uuid, data: Partial<IUserEntity>) {
    await this.userRepo.save({ id: userId, ...data });
    return await this.userRepo.findOneOrFail({ where: { id: userId } });
  }

  async forgotPassword(dto: IForgotPasswordPayload) {
    const user = await this.userRepo.findOne({ where: { email: dto.email } });
    if (!user) {
      this.logger.debug(
        `User ${dto.email} does not exist, skipping Forgot Password email`,
      );
      return;
    }
    if (!user.email) {
      throw new UnprocessableEntityException(
        'This employee account does not have login access configured',
      );
    }
    if (!user.password && user.socialProvider !== AuthProviderType.EMAIL) {
      throw new UnprocessableEntityException(
        `User was created via social login, unable to reset password!`,
      );
    }
    const hash = crypto.randomBytes(64).toString('hex');
    user.verificationHash = hash;
    await user.save();
    const context: IResetPasswordEmailContext = {
      passwordResetLink: `${this.publicApiBaseUrl}/api/v1/auth/email/reset-password?code=${hash}`,
      title: 'Reset Your Password',
      username: user.firstName ?? user.email,
    };

    await this.emailService.sendMail({
      templatePath: 'reset-password.hbs',
      context,
      to: user.email,
      subject: 'Reset Your Password',
    });
  }

  async resetPassword(dto: IResetPasswordPayload & { code: string }) {
    const user = await this.userRepo.findOne({
      where: { email: dto.email },
    });
    if (!user) {
      this.logger.debug(
        `User ${dto.email} does not exist, no password to reset!`,
      );
      throw new UnprocessableEntityException(`Unable to reset password`);
    }
    if (user.verificationHash !== dto.code) {
      this.logger.error(
        `User ${dto.email} is trying to reset their password with an invalid verification code!`,
      );
      throw new UnprocessableEntityException(`Verification code is not valid`);
    }
    this.logger.log(`Updating password for user ${dto.email}`);
    user.password = dto.password;
    user.verificationHash = null;
    await user.save();
  }

  async deleteUser(userId: Uuid): Promise<void> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) {
      this.logger.log(
        `Request received to delete user ${userId} - but user does not exist!`,
      );
      throw new UnprocessableEntityException(`Error deleting user`);
    }
    await user.remove();
  }
}
