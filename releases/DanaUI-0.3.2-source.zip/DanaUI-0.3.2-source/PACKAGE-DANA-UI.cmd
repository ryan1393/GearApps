@echo off
setlocal
cd /d "%~dp0"
title Dana UI - Package
if not exist "node_modules" (
  echo [FAIL] Run SETUP-DANA-UI.cmd once first.
  pause
  exit /b 1
)
call npm run pack
if errorlevel 1 goto :fail
echo.
echo [PASS] Dana UI package created under artifacts.
pause
exit /b 0
:fail
echo.
echo [FAIL] Dana UI package failed.
pause
exit /b 1
