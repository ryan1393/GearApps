@echo off
setlocal
cd /d "%~dp0"
title Dana UI - Setup
call npm ci
if errorlevel 1 goto :fail
call npx playwright install chromium
if errorlevel 1 goto :fail
call npm run check
if errorlevel 1 goto :fail
echo.
echo [PASS] Dana UI setup/build complete.
pause
exit /b 0
:fail
echo.
echo [FAIL] Dana UI setup/build failed.
pause
exit /b 1
