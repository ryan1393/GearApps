@echo off
setlocal
cd /d "%~dp0"
title Dana UI - Build
if not exist "node_modules" (
  echo [FAIL] Run SETUP-DANA-UI.cmd once first.
  pause
  exit /b 1
)
call npm run check
if errorlevel 1 goto :fail
echo.
echo [PASS] Dana UI build complete.
pause
exit /b 0
:fail
echo.
echo [FAIL] Dana UI build failed.
pause
exit /b 1
