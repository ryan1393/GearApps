import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';

const artifacts=path.join(process.cwd(),'artifacts');
fs.mkdirSync(artifacts,{recursive:true});

let r;
if(process.platform==='win32'){
  const comspec=process.env.ComSpec||process.env.COMSPEC||'cmd.exe';
  r=cp.spawnSync(comspec,[
    '/d','/s','/c',
    'npm.cmd pack ./dist --pack-destination artifacts'
  ],{cwd:process.cwd(),stdio:'inherit',shell:false,windowsHide:false});
}else{
  r=cp.spawnSync('npm',
    ['pack','./dist','--pack-destination',artifacts],
    {cwd:process.cwd(),stdio:'inherit',shell:false});
}
if(r.error)throw r.error;
if(r.status!==0)process.exit(r.status??1);
console.log('[PASS] Dana UI package created under artifacts/.');
