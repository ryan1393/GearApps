import {
  CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  OnInit,
  } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GearToastService } from '@gearapps/manufacturing/frontend/util-common';
import { Observable } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthSessionService } from '@gearapps/manufacturing/frontend/data-access-user';
import {
  CuttergrindNumberedShelfTag,
  CuttergrindRoughShelfTag,
  parseCuttergrindRoughShelfTag,
  parseCuttergrindNumberedShelfTag,
  parseSummaryShelfTag,
  SummaryShelfTag,
} from '@gearapps/manufacturing/shared/util-constants';
import {
  AdminApiService,
  AdminLocationRow,
  AdminUser,
  CutterBodyRow,
  DepartmentRow,
  MachineRow,
  ModelRow,
  PartRow,
  PartSummaryRow,
  PartTypeRow,
  RollMasterRow,
  adminApiErrorText,
  AdminContainerRow,
  AdminTrayRow,
  AssetTagKind,
} from '../admin-api.service';

type AdminTab = 'users' | 'part-summaries' | 'parts' | 'roll-masters' | 'models' | 'machines' | 'trays' | 'containers' | 'locations' | 'cutter-bodies';
import {
  DanaPageHeaderComponent,
} from '@dana/ui';

@Component({
  selector: 'gear-admin-users-page',
  standalone: true,
  imports: [CommonModule, FormsModule, DanaPageHeaderComponent],
  templateUrl: './frontend-feature-admin-users.component.html',
  styleUrls: ['./frontend-feature-admin-users.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FrontendFeatureAdminUsersComponent implements OnInit {
  private readonly api = inject(AdminApiService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly toast = inject(GearToastService);
  readonly session = inject(AuthSessionService);

  activeTab: AdminTab = 'users';
  busy = false;
  message = '';
  error = '';

  users: AdminUser[] = [];
  partSummaries: PartSummaryRow[] = [];
  partTypes: PartTypeRow[] = [];
  parts: PartRow[] = [];
  rollMasters: RollMasterRow[] = [];
  models: ModelRow[] = [];
  departments: DepartmentRow[] = [];
  machines: MachineRow[] = [];
  trays: AdminTrayRow[] = [];
  containers: AdminContainerRow[] = [];
  locations: AdminLocationRow[] = [];
  cutterBodies: CutterBodyRow[] = [];
  danaAssignments: Record<string, string | undefined> = {};
  userSearch = '';
  partSummarySearch = '';
  partSearch = '';
  rollMasterSearch = '';
  modelSearch = '';
  machineSearch = '';
  traySearch = '';
  containerSearch = '';
  locationSearch = '';
  cutterBodySearch = '';
  editingUserId: string | null = null;
  editingPartSummaryId: string | null = null;
  editingMachineId: string | null = null;
  editingLocationId: string | null = null;
  editingCutterBodyId: string | null = null;
  rollMasterEdits: Record<string, { current_quantity: number; minimum_quantity: number }> = {};
  printingTagId: string | null = null;

  userForm = {
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    role: 'user',
    departmentId: '',
  };

  summaryForm = {
    number: '',
    revision: '',
    model_id: '',
    hos: '',
  };

  partForm: {
    part_number: string;
    summary_id: string;
    part_type_id: string;
    teeth: number | null;
  } = {
    part_number: '',
    summary_id: '',
    part_type_id: '',
    teeth: null,
  };

  modelForm: {
    model_number: number | null;
    model_type: string;
  } = {
    model_number: null,
    model_type: '',
  };

  machineForm: {
    machine_number: string;
    department_id: string;
    cell: number | null;
    description: string;
    machine_type: 'PRODUCTION' | 'CUTTER_BUILDER';
  } = {
    machine_number: '',
    department_id: '',
    cell: null,
    description: '',
    machine_type: 'PRODUCTION',
  };

  trayForm = {
    serial_number: '',
  };

  containerForm = {
    serial_number: '',
  };

  locationForm = {
    serial_number: '',
    number: '',
    description: '',
    department: '',
    location_type: 'INTERNAL',
    enabled: true,
  };

  cutterBodyForm = {
    mf_serial_number: '',
    dana_serial_number: '',
    description: '',
  };

  ngOnInit(): void {
    this.refreshAll();
  }

  setTab(tab: AdminTab): void {
    this.activeTab = tab;
    this.clearNotice();
  }

  createUser(): void {
    if (!this.userForm.email.trim() || !this.userForm.departmentId || (!this.editingUserId && !this.userForm.password)) {
      this.error = this.editingUserId
        ? 'Email and department are required.'
        : 'Email, password, and department are required.';
      return;
    }

    const request = this.editingUserId
      ? this.api.updateUser(this.editingUserId, {
          email: this.userForm.email.trim(),
          firstName: this.userForm.firstName.trim() || null,
          lastName: this.userForm.lastName.trim() || null,
          role: this.userForm.role,
          departmentId: this.userForm.departmentId,
        })
      : this.api.createUser({
          email: this.userForm.email.trim(),
          password: this.userForm.password,
          firstName: this.userForm.firstName.trim() || null,
          lastName: this.userForm.lastName.trim() || null,
          role: this.userForm.role,
          departmentId: this.userForm.departmentId,
        });

    this.runCreate(request, this.editingUserId ? 'User updated.' : 'User created.', () => {
      this.resetUserForm();
      this.loadUsers();
    });
  }

  beginEditUser(user: AdminUser): void {
    this.editingUserId = user.id;
    this.userForm = {
      email: user.email || '', password: '', firstName: user.firstName || '', lastName: user.lastName || '',
      role: user.role || 'user', departmentId: user.departmentId || '',
    };
    this.clearNotice(); this.cdr.markForCheck();
  }

  cancelUserEdit(): void { this.resetUserForm(); this.clearNotice(); this.cdr.markForCheck(); }

  toggleUserEnabled(user: AdminUser): void {
    const active = !user.active;
    this.runCreate(this.api.updateUser(user.id, { active }), `User ${active ? 'enabled' : 'disabled'}.`, () => this.loadUsers());
  }

  createPartSummary(): void {
    const number = this.summaryForm.number.trim();
    if (!number) { this.error = 'Part Summary number is required.'; return; }
    const payload = {
      number, revision: this.summaryForm.revision.trim(), model_id: this.summaryForm.model_id || null,
      hos: this.summaryForm.hos.trim() || null, active: true, enabled: true,
    };
    const request = this.editingPartSummaryId
      ? this.api.updatePartSummary(this.editingPartSummaryId, payload)
      : this.api.createPartSummary(payload);
    this.runCreate(request, this.editingPartSummaryId ? 'Part Summary updated.' : 'Part Summary created.', () => {
      this.resetPartSummaryForm(); this.loadPartSummaries();
    });
  }

  beginEditPartSummary(summary: PartSummaryRow): void {
    this.editingPartSummaryId = summary.id;
    this.summaryForm = { number: summary.number, revision: summary.revision || '', model_id: summary.model_id || '', hos: summary.hos || '' };
    this.clearNotice(); this.cdr.markForCheck();
  }

  cancelPartSummaryEdit(): void { this.resetPartSummaryForm(); this.clearNotice(); this.cdr.markForCheck(); }

  togglePartSummaryEnabled(summary: PartSummaryRow): void {
    const enabled = !summary.enabled;
    this.runCreate(this.api.updatePartSummary(summary.id, { enabled, active: enabled }), `Part Summary ${summary.number} ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadPartSummaries());
  }

  createPart(): void {
    const partNumber = this.partForm.part_number.trim();
    if (!partNumber || !this.partForm.summary_id || !this.partForm.part_type_id) {
      this.error = 'Part number, Part Summary, and Part Type are required.';
      return;
    }

    this.runCreate(
      this.api.createPart({
        part_number: partNumber,
        summary_id: this.partForm.summary_id,
        part_type_id: this.partForm.part_type_id,
        teeth: this.partForm.teeth,
        active: true,
        enabled: true,
      }),
      'Part created.',
      () => {
        this.partForm = {
          part_number: '',
          summary_id: '',
          part_type_id: '',
          teeth: null,
        };
        this.loadParts();
      },
    );
  }

  togglePartEnabled(part: PartRow): void {
    const enabled = !part.enabled;
    this.runCreate(this.api.updatePart(part.id, { enabled, active: enabled }), `Part ${part.part_number} ${enabled ? 'enabled' : 'disabled'}.`, () => { this.loadParts(); this.loadRollMasters(); });
  }

  createModel(): void {
    if (this.modelForm.model_number == null && !this.modelForm.model_type.trim()) {
      this.error = 'Model number or model type is required.';
      return;
    }

    this.runCreate(
      this.api.createModel({
        model_number: this.modelForm.model_number,
        model_type: this.modelForm.model_type.trim() || null,
        active: true,
      }),
      'Model created.',
      () => {
        this.modelForm = { model_number: null, model_type: '' };
        this.loadModels();
      },
    );
  }

  toggleModelEnabled(model: ModelRow): void {
    const enabled = !model.enabled;
    this.runCreate(this.api.updateModel(model.id, { enabled, active: enabled }), `Model ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadModels());
  }

  createMachine(): void {
    if (!this.machineForm.machine_number.trim() || !this.machineForm.department_id) {
      this.error = 'Machine number and department are required.'; return;
    }
    const payload = {
      machine_number: this.machineForm.machine_number.trim(), department_id: this.machineForm.department_id,
      cell: this.machineForm.cell, description: this.machineForm.description.trim() || null,
      machine_type: this.machineForm.machine_type, active: true,
    };
    const request = this.editingMachineId
      ? this.api.updateMachine(this.editingMachineId, payload)
      : this.api.createMachine(payload);
    this.runCreate(request, this.editingMachineId ? 'Machine updated.' : 'Machine created.', () => {
      this.resetMachineForm(); this.loadMachines();
    });
  }

  beginEditMachine(machine: MachineRow): void {
    this.editingMachineId = machine.id;
    this.machineForm = {
      machine_number: machine.machine_number, department_id: machine.department_id, cell: machine.cell,
      description: machine.description || '', machine_type: machine.machine_type === 'CUTTER_BUILDER' ? 'CUTTER_BUILDER' : 'PRODUCTION',
    };
    this.clearNotice(); this.cdr.markForCheck();
  }

  cancelMachineEdit(): void { this.resetMachineForm(); this.clearNotice(); this.cdr.markForCheck(); }

  toggleMachineEnabled(machine: MachineRow): void {
    const enabled = !machine.enabled;
    this.runCreate(this.api.updateMachine(machine.id, { enabled, active: enabled }), `Machine ${machine.machine_number} ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadMachines());
  }

  private adminSearchMatches(searchText: string, values: unknown[]): boolean {
    const search = searchText.trim().toUpperCase();
    if (!search) return true;

    return values
      .filter((value) => value !== null && value !== undefined && String(value).trim())
      .join(' ')
      .toUpperCase()
      .includes(search);
  }

  get filteredUsers(): AdminUser[] {
    return this.users.filter((user) =>
      this.adminSearchMatches(this.userSearch, [
        user.fullName,
        user.firstName,
        user.lastName,
        user.email,
        user.role,
        this.departmentName(user.departmentId),
        user.active ? 'active' : 'inactive',
      ]),
    );
  }

  get filteredPartSummaries(): PartSummaryRow[] {
    return this.partSummaries.filter((summary) =>
      this.adminSearchMatches(this.partSummarySearch, [
        summary.number,
        summary.revision,
        summary.model?.model_number,
        summary.model?.model_type,
        summary.hos,
        summary.active ? 'active' : 'inactive',
        summary.enabled ? 'enabled' : 'disabled',
      ]),
    );
  }

  get filteredParts(): PartRow[] {
    return this.parts.filter((part) =>
      this.adminSearchMatches(this.partSearch, [
        part.part_number,
        part.summary?.number,
        part.summary?.revision,
        part.part_type?.code,
        part.part_type?.name,
        part.teeth,
        part.active ? 'active' : 'inactive',
        part.enabled ? 'enabled' : 'disabled',
      ]),
    );
  }

  get filteredModels(): ModelRow[] {
    return this.models.filter((model) =>
      this.adminSearchMatches(this.modelSearch, [
        model.model_number,
        model.model_type,
        model.active ? 'active' : 'inactive',
        model.enabled ? 'enabled' : 'disabled',
      ]),
    );
  }

  get filteredMachines(): MachineRow[] {
    return this.machines.filter((machine) =>
      this.adminSearchMatches(this.machineSearch, [
        machine.machine_number,
        machine.department?.code,
        machine.department?.description,
        machine.cell,
        machine.description,
        machine.machine_type,
        machine.active ? 'active' : 'inactive',
        machine.enabled ? 'enabled' : 'disabled',
      ]),
    );
  }

  get filteredRollMasterParts(): PartRow[] {
    return this.parts.filter((part) => this.adminSearchMatches(this.rollMasterSearch, [
      part.part_number, part.summary?.number, part.part_type?.code,
      part.roll_master?.current_quantity ?? 0, part.roll_master?.minimum_quantity ?? part.roll_master?.required_count ?? 0,
    ]));
  }

  rollMasterEdit(part: PartRow): { current_quantity: number; minimum_quantity: number } {
    if (!this.rollMasterEdits[part.id]) {
      const configured = this.rollMasters.find((row) => row.part_id === part.id) ?? part.roll_master ?? null;
      this.rollMasterEdits[part.id] = {
        current_quantity: configured?.current_quantity ?? 0,
        minimum_quantity: configured?.minimum_quantity ?? configured?.required_count ?? 0,
      };
    }
    return this.rollMasterEdits[part.id];
  }

  rollMasterRecord(part: PartRow): RollMasterRow | null {
    return this.rollMasters.find((row) => row.part_id === part.id) ?? part.roll_master ?? null;
  }

  rollMasterLow(part: PartRow): boolean {
    const record = this.rollMasterRecord(part);
    if (record && !record.enabled) return false;
    const edit = this.rollMasterEdit(part);
    return edit.minimum_quantity > 0 && edit.current_quantity <= edit.minimum_quantity;
  }

  toggleRollMasterEnabled(part: PartRow): void {
    const record = this.rollMasterRecord(part);
    if (!record) { this.error = `Save a Roll Master quantity for ${part.part_number} before disabling it.`; return; }
    const enabled = !record.enabled;
    this.runCreate(this.api.updateRollMaster(record.id, { enabled, active: enabled }), `Roll Master for ${part.part_number} ${enabled ? 'enabled' : 'disabled'}.`, () => { this.loadRollMasters(); this.loadParts(); });
  }

  saveRollMaster(part: PartRow): void {
    const edit = this.rollMasterEdit(part);
    if (edit.current_quantity < 0 || edit.minimum_quantity < 0 || !Number.isInteger(edit.current_quantity) || !Number.isInteger(edit.minimum_quantity)) {
      this.error = 'Roll Master current and minimum quantities must be whole numbers of 0 or greater.'; return;
    }
    const existing = this.rollMasters.find((row) => row.part_id === part.id) ?? part.roll_master ?? null;
    const request = existing
      ? this.api.updateRollMaster(existing.id, { current_quantity: edit.current_quantity, minimum_quantity: edit.minimum_quantity, active: true, enabled: true })
      : this.api.createRollMaster({ part_id: part.id, current_quantity: edit.current_quantity, minimum_quantity: edit.minimum_quantity, active: true, enabled: true });
    this.runCreate(request, `Roll Master quantity saved for ${part.part_number}.`, () => { this.loadRollMasters(); this.loadParts(); });
  }

  private normalizeSequentialAssetSerial(prefix: 'T' | 'C', input: string): string {
    const raw = input.trim().toUpperCase();
    const match = new RegExp(`^(?:${prefix})?0*([0-9]+)$`).exec(raw);
    if (!match) return '';
    const numeric = Number.parseInt(match[1], 10);
    if (!Number.isSafeInteger(numeric) || numeric < 1) return '';
    return `${prefix}${String(numeric).padStart(4, '0')}`;
  }

  get traySerialPreview(): string {
    return this.normalizeSequentialAssetSerial('T', this.trayForm.serial_number);
  }

  get containerSerialPreview(): string {
    return this.normalizeSequentialAssetSerial('C', this.containerForm.serial_number);
  }

  createTray(): void {
    const input = this.trayForm.serial_number.trim();
    const serial = this.normalizeSequentialAssetSerial('T', input);
    if (!serial) {
      this.error = 'Tray serial must be T followed by digits, for example T0301 or 301.';
      return;
    }

    this.runCreate(
      this.api.createTray({ serial_number: input, blade_count: 0, enabled: true }),
      `Tray ${serial} created.`,
      () => {
        this.trayForm = { serial_number: '' };
        this.loadTrays();
      },
    );
  }

  createContainer(): void {
    const input = this.containerForm.serial_number.trim();
    const serial = this.normalizeSequentialAssetSerial('C', input);
    if (!serial) {
      this.error = 'Container serial must be C followed by digits, for example C0101 or 101.';
      return;
    }

    this.runCreate(
      this.api.createContainer({ serial_number: input, enabled: true }),
      `Container ${serial} created.`,
      () => {
        this.containerForm = { serial_number: '' };
        this.loadContainers();
      },
    );
  }

  toggleTrayEnabled(tray: AdminTrayRow): void {
    const enabled = !tray.enabled;
    this.runCreate(this.api.updateTray(tray.id, { enabled }), `Tray ${tray.serial_number} ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadTrays());
  }

  toggleContainerEnabled(container: AdminContainerRow): void {
    const enabled = !container.enabled;
    this.runCreate(this.api.updateContainer(container.id, { enabled }), `Container ${container.serial_number} ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadContainers());
  }

  get filteredTrays(): AdminTrayRow[] {
    return this.trays.filter((tray) =>
      this.adminSearchMatches(this.traySearch, [
        tray.serial_number,
        tray.blade_count,
        tray.current_stage?.code,
        tray.current_stage?.name,
        tray.current_location?.serial_number,
        tray.current_container?.serial_number,
        tray.enabled ? 'active' : 'inactive',
      ]),
    );
  }

  get filteredContainers(): AdminContainerRow[] {
    return this.containers.filter((container) =>
      this.adminSearchMatches(this.containerSearch, [
        container.serial_number,
        container.tray_count,
        container.blade_count,
        container.enabled ? 'active' : 'inactive',
      ]),
    );
  }

  get filteredLocations(): AdminLocationRow[] {
    return this.locations.filter((location) =>
      this.adminSearchMatches(this.locationSearch, [
        location.serial_number,
        location.number,
        location.description,
        location.department,
        location.location_type,
        location.tray_count,
        location.blade_count,
        location.enabled ? 'active' : 'inactive',
      ]),
    );
  }

  get filteredCutterBodies(): CutterBodyRow[] {
    return this.cutterBodies.filter((body) =>
      this.adminSearchMatches(this.cutterBodySearch, [
        body.mf_serial_number,
        body.dana_serial_number,
        body.description,
        body.enabled ? 'enabled' : 'disabled',
      ]),
    );
  }

  get locationShelfPreview() {
    return (
      parseCuttergrindRoughShelfTag(this.locationForm.serial_number) ??
      parseCuttergrindNumberedShelfTag(this.locationForm.serial_number) ??
      parseSummaryShelfTag(this.locationForm.serial_number)
    );
  }

  locationShelfDisplay(shelf: CuttergrindRoughShelfTag | CuttergrindNumberedShelfTag | SummaryShelfTag): string {
    return 'shelfNumber' in shelf
      ? `Shelf ${shelf.shelfNumber}`
      : `Summary ${shelf.summaryNumber}`;
  }

  saveLocation(): void {
    const serialNumber = this.locationForm.serial_number.trim().toUpperCase();
    const numberedShelf = parseCuttergrindRoughShelfTag(serialNumber) ?? parseCuttergrindNumberedShelfTag(serialNumber);
    const shelfTag = numberedShelf ? null : parseSummaryShelfTag(serialNumber);
    const number =
      numberedShelf?.shelfNumber ??
      shelfTag?.summaryNumber ??
      this.locationForm.number.trim();

    if (!serialNumber || !number) {
      this.error = 'Location barcode and location number are required.';
      return;
    }

    const payload = {
      serial_number: serialNumber,
      number,
      description: this.locationForm.description.trim() || null,
      department:
        numberedShelf?.department ?? shelfTag?.department ??
        (this.locationForm.department.trim().toUpperCase() || null),
      location_type:
        numberedShelf?.locationType ?? shelfTag?.locationType ??
        (this.locationForm.location_type.trim().toUpperCase() || 'INTERNAL'),
      enabled: this.locationForm.enabled,
    };

    const request = this.editingLocationId
      ? this.api.updateLocation(this.editingLocationId, payload)
      : this.api.createLocation(payload);

    this.runCreate(
      request,
      this.editingLocationId ? 'Location updated.' : 'Location created.',
      () => {
        this.resetLocationForm();
        this.loadLocations();
      },
    );
  }

  beginEditLocation(location: AdminLocationRow): void {
    this.editingLocationId = location.id;
    this.locationForm = {
      serial_number: location.serial_number,
      number: location.number,
      description: location.description || '',
      department: location.department || '',
      location_type: location.location_type || 'INTERNAL',
      enabled: location.enabled,
    };
    this.clearNotice();
    this.cdr.markForCheck();
  }

  cancelLocationEdit(): void {
    this.resetLocationForm();
    this.clearNotice();
    this.cdr.markForCheck();
  }

  toggleLocationEnabled(location: AdminLocationRow): void {
    const nextEnabled = !location.enabled;
    this.runCreate(
      this.api.updateLocation(location.id, { enabled: nextEnabled }),
      `Location ${location.serial_number} ${nextEnabled ? 'enabled' : 'disabled'}.`,
      () => this.loadLocations(),
    );
  }

  printTag(
    kind: AssetTagKind,
    recordId: string,
    serialNumber: string,
  ): void {
    if (this.printingTagId) return;
    this.clearNotice();
    this.printingTagId = recordId;
    this.api.printAssetTag(kind, recordId).subscribe({
      next: (result) => {
        this.printingTagId = null;
        if (!result.printed) {
          this.api.downloadAssetTagPrn(result);
        }
        this.message = result.printed
          ? `${result.serial_number} tag sent to the IPL printer.`
          : `${result.message} ${result.file_name} downloaded.`;
        this.cdr.markForCheck();
      },
      error: (error: HttpErrorResponse) => {
        this.printingTagId = null;
        this.error = adminApiErrorText(error);
        if (!this.error) {
          this.error = `Could not print ${serialNumber} tag.`;
        }
        this.cdr.markForCheck();
      },
    });
  }

  createCutterBody(): void {
    if (!this.cutterBodyForm.mf_serial_number.trim()) { this.error = 'MF / manufacturer serial number is required.'; return; }
    const payload = {
      mf_serial_number: this.cutterBodyForm.mf_serial_number.trim(),
      dana_serial_number: this.cutterBodyForm.dana_serial_number.trim() || null,
      description: this.cutterBodyForm.description.trim() || null,
    };
    const request = this.editingCutterBodyId
      ? this.api.updateCutterBody(this.editingCutterBodyId, payload)
      : this.api.createCutterBody(payload);
    this.runCreate(request, this.editingCutterBodyId ? 'Cutter body updated.' : 'Cutter body created.', () => {
      this.resetCutterBodyForm(); this.loadCutterBodies();
    });
  }

  beginEditCutterBody(body: CutterBodyRow): void {
    this.editingCutterBodyId = body.id;
    this.cutterBodyForm = { mf_serial_number: body.mf_serial_number || '', dana_serial_number: body.dana_serial_number || '', description: body.description || '' };
    this.clearNotice(); this.cdr.markForCheck();
  }

  cancelCutterBodyEdit(): void { this.resetCutterBodyForm(); this.clearNotice(); this.cdr.markForCheck(); }

  toggleCutterBodyEnabled(body: CutterBodyRow): void {
    const enabled = !body.enabled;
    this.runCreate(this.api.updateCutterBody(body.id, { enabled }), `Cutter body ${enabled ? 'enabled' : 'disabled'}.`, () => this.loadCutterBodies());
  }

  departmentName(departmentId?: string | null): string {
    if (!departmentId) return 'No department';
    return (
      this.departments.find((department) => department.id === departmentId)
        ?.description || 'Unknown department'
    );
  }

  assignDanaSerial(body: CutterBodyRow): void {
    if (body.dana_serial_number) return;
    const dana = (this.danaAssignments[body.id] || '').trim().toUpperCase();
    if (!dana) {
      this.error = 'Enter the etched Dana serial number.';
      return;
    }

    this.runCreate(
      this.api.assignCutterBodyDanaSerial(body.id, dana),
      `Dana serial ${dana} assigned.`,
      () => {
        delete this.danaAssignments[body.id];
        this.loadCutterBodies();
      },
    );
  }

  private refreshAll(): void {
    this.loadUsers();
    this.loadModels();
    this.loadDepartments();
    this.loadPartSummaries();
    this.loadPartTypes();
    this.loadParts();
    this.loadRollMasters();
    this.loadMachines();
    this.loadTrays();
    this.loadContainers();
    this.loadLocations();
    this.loadCutterBodies();
  }

  private loadUsers(page = 1, accumulated: AdminUser[] = []): void {
    this.api.listUsers(page, 50).subscribe({
        next: (response) => {
          const rows = response.data ?? [];
          const combined = [...accumulated, ...rows];
          if (rows.length === 50) {
            this.loadUsers(page + 1, combined);
            return;
          }
          this.users = combined;
          this.cdr.markForCheck();
        },
        error: (error) => this.handleLoadError(error),
      });
  }

  private loadPartSummaries(
    page = 1,
    accumulated: PartSummaryRow[] = [],
  ): void {
    this.api.listPartSummaries(page, 50).subscribe({
        next: (response) => {
          const rows = response.data ?? [];
          const combined = [...accumulated, ...rows];
          if (rows.length === 50) {
            this.loadPartSummaries(page + 1, combined);
            return;
          }
          this.partSummaries = combined;
          this.cdr.markForCheck();
        },
        error: (error) => this.handleLoadError(error),
      });
  }

  private loadPartTypes(): void {
    this.api.listPartTypes().subscribe({
      next: (rows) => {
        this.partTypes = rows ?? [];
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadParts(): void {
    this.api.listParts().subscribe({
      next: (rows) => {
        this.parts = rows ?? [];
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadRollMasters(): void {
    this.api.listRollMasters().subscribe({
      next: (rows) => {
        this.rollMasters = rows ?? [];
        this.rollMasterEdits = {};
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadModels(): void {
    this.api.listModels().subscribe({
      next: (rows) => {
        this.models = rows ?? [];
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadDepartments(): void {
    this.api.listDepartments().subscribe({
        next: (rows) => {
          this.departments = rows ?? [];
          this.cdr.markForCheck();
        },
        error: (error) => this.handleLoadError(error),
      });
  }

  private loadMachines(): void {
    this.api.listMachines().subscribe({
      next: (rows) => {
        this.machines = rows ?? [];
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadTrays(
    page = 1,
    accumulated: AdminTrayRow[] = [],
  ): void {
    this.api.listTrays(page, 50).subscribe({
      next: (response) => {
        const rows = response.data ?? [];
        const combined = [...accumulated, ...rows];
        if (rows.length === 50) {
          this.loadTrays(page + 1, combined);
          return;
        }
        this.trays = combined;
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadContainers(
    page = 1,
    accumulated: AdminContainerRow[] = [],
  ): void {
    this.api.listContainers(page, 50).subscribe({
      next: (response) => {
        const rows = response.data ?? [];
        const combined = [...accumulated, ...rows];
        if (rows.length === 50) {
          this.loadContainers(page + 1, combined);
          return;
        }
        this.containers = combined;
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadLocations(
    page = 1,
    accumulated: AdminLocationRow[] = [],
  ): void {
    this.api.listLocations(page, 50).subscribe({
      next: (response) => {
        const rows = response.data ?? [];
        const combined = [...accumulated, ...rows];
        if (rows.length === 50) {
          this.loadLocations(page + 1, combined);
          return;
        }
        this.locations = combined;
        this.cdr.markForCheck();
      },
      error: (error) => this.handleLoadError(error),
    });
  }

  private loadCutterBodies(): void {
    this.api.listCutterBodies().subscribe({
        next: (rows) => {
          this.cutterBodies = rows ?? [];
          this.cdr.markForCheck();
        },
        error: (error) => this.handleLoadError(error),
      });
  }

  private resetUserForm(): void {
    this.editingUserId = null;
    this.userForm = { email: '', password: '', firstName: '', lastName: '', role: 'user', departmentId: '' };
  }

  private resetPartSummaryForm(): void {
    this.editingPartSummaryId = null;
    this.summaryForm = { number: '', revision: '', model_id: '', hos: '' };
  }

  private resetMachineForm(): void {
    this.editingMachineId = null;
    this.machineForm = { machine_number: '', department_id: '', cell: null, description: '', machine_type: 'PRODUCTION' };
  }

  private resetCutterBodyForm(): void {
    this.editingCutterBodyId = null;
    this.cutterBodyForm = { mf_serial_number: '', dana_serial_number: '', description: '' };
  }

  private resetLocationForm(): void {
    this.editingLocationId = null;
    this.locationForm = {
      serial_number: '',
      number: '',
      description: '',
      department: '',
      location_type: 'INTERNAL',
      enabled: true,
    };
  }

  private runCreate(
    request: Observable<unknown>,
    successMessage: string,
    onSuccess: () => void,
  ): void {
    this.busy = true;
    this.clearNotice();
    request.subscribe({
      next: () => {
        this.busy = false;
        this.message = '';
        this.toast.success(successMessage, 'Saved');
        onSuccess();
        this.cdr.markForCheck();
      },
      error: (error: HttpErrorResponse) => {
        this.busy = false;
        const message = this.errorMessage(error);
        this.error = '';
        this.toast.error(message, 'Save failed');
        this.cdr.markForCheck();
      },
    });
  }

  private handleLoadError(error: HttpErrorResponse): void {
    if (!this.error) {
      this.error = this.errorMessage(error);
    }
    this.cdr.markForCheck();
  }

  private errorMessage(error: HttpErrorResponse): string {
    return adminApiErrorText(error);
  }

  private clearNotice(): void {
    this.message = '';
    this.error = '';
  }
}
