import nx from '@nx/eslint-plugin';
import baseConfig from '../../eslint.config.mjs';

export default [
  ...nx.configs['flat/angular'],
  ...nx.configs['flat/angular-template'],
  ...baseConfig,
  { files: ['**/*.ts'], rules: { '@angular-eslint/directive-selector': ['error', { type: 'attribute', prefix: 'gear', style: 'camelCase' }], '@angular-eslint/component-selector': ['error', { type: 'element', prefix: 'gear', style: 'kebab-case' }] } },
  // Build configuration shares the workspace Tailwind factory outside application source.
  { files: ['tailwind.config.js'], rules: { '@nx/enforce-module-boundaries': 'off' } },
];
