# Gear Apps shared workflow icons

These SVGs are the single shared icon set used by Blade Tracking, Cutter Builder, Greenshed, Lapper, Admin navigation, and shared login/search UI.

Dashboard and navigation templates reference semantic icon classes defined in `libs/shared/ui-tailwind/src/styles/gear-apps/components/icons.css`. Keep icons here rather than creating app-local copies.
